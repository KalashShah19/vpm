# Task Management UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/aaronmcg/pen/GRjaRva](https://codepen.io/aaronmcg/pen/GRjaRva).

Task Management UI created for fun, you can drag and drop tasks over each other using Drag and Drop API.

Design of the POC comes from Dwinawan ( https://dribbble.com/shots/14552329--Exploration-Task-Management-Dashboard) 